##############################
ctrl_bps documentation preview
##############################

.. This page is for local development only. It isn't published to pipelines.lsst.io.

.. Link the index pages of package and module documentation directions (listed in manifest.yaml).

.. toctree::
   :maxdepth: 1

   lsst.ctrl.bps/index
