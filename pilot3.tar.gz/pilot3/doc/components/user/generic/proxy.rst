..
    Pilot 2 pilot.user.generic.proxy doc file

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0

    Authors:
     - Paul Nilsson, paul.nilsson@cern.ch, 2018

proxy
=====

.. automodule:: pilot.user.generic.proxy
    :members:
    :private-members:
    :special-members:
    :undoc-members:
