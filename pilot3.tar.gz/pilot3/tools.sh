# tar czf pilot3-dev.tar.gz pilot3/
# cp pilot3-dev.tar.gz ~/www/wiscgroup/
# wget https://wguan-wisc.web.cern.ch/wguan-wisc/pilot3-dev.tar.gz
#/sdf/data/rubin/panda_jobs/panda_env_pilot/pilot3.tar.gz

cd /afs/cern.ch/user/w/wguan/workdisk/panda; rm pilot3-dev.tar.gz ; tar czf pilot3-dev.tar.gz pilot3; cp pilot3-dev.tar.gz ~/www/wiscgroup/

